class Bank:
    def __init__(self, name):
        self.name = name
        self.__balance = 0

    def deposit(self, amount):
        """YOUR CODE HERE"""

    def withdraw(self, amount):
        """YOUR CODE HERE"""

    @property
    def balance(self):
        return self.__balance
